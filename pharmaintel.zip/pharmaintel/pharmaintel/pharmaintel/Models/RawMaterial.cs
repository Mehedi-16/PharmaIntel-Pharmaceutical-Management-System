﻿using System;
using System.ComponentModel.DataAnnotations;

namespace pharmaintel.Models
{
    public class RawMaterial
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        public string Category { get; set; }

        public string Supplier { get; set; }

        [Required]
        [Range(0, int.MaxValue)]
        public int Quantity { get; set; }

        [Required]
        [Range(0.0, double.MaxValue)]
        public decimal UnitPrice { get; set; }

        public DateTime? ExpiryDate { get; set; }
    }
}
