﻿using System.ComponentModel.DataAnnotations;

namespace pharmaintel.Models
{
    public class LoginViewModel
    {
        [Required]
        public string EmailOrUsername { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
