﻿namespace pharmaintel.Models
{
   
        public class SalesForecastModel
        {
            public string ProductName { get; set; }
            public int PredictedDemand { get; set; }
            public string RestockSuggestion { get; set; }
            public string PromotionIdea { get; set; }
        }
    
}
