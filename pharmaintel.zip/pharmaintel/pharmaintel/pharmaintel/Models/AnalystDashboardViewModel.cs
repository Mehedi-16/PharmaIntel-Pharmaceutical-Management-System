﻿namespace pharmaintel.Models
{
    public class AnalystDashboardViewModel
    {
        public List<WeeklySale> WeeklySales { get; set; }
        public List<ForecastItem> Forecasts { get; set; }
        public List<RawUsage> RawMaterialUsages { get; set; }
        public List<ProfitLossItem> ProfitLossSummaries { get; set; }
        public List<string> AIAlerts { get; set; }
        public List<string> ExpiringSoon { get; set; }
    }

    public class WeeklySale
    {
        public string Date { get; set; }
        public decimal Total { get; set; }
    }

    public class ForecastItem
    {
        public string Product { get; set; }
        public int ForecastQty { get; set; }
    }

    public class RawUsage
    {
        public string Name { get; set; }
        public int UsedQty { get; set; }
    }

    public class ProfitLossItem
    {
        public string Name { get; set; }
        public decimal Revenue { get; set; }
        public decimal Cost { get; set; }
    }
}
