﻿namespace pharmaintel.Models
{
    public class ReportFilterModel
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Category { get; set; }
        public int? ProductId { get; set; }
    }

    public class SalesReportItem
    {
        public string ProductName { get; set; }
        public int QuantitySold { get; set; }
        public decimal TotalRevenue { get; set; }
        public decimal Profit { get; set; }
    }
}
