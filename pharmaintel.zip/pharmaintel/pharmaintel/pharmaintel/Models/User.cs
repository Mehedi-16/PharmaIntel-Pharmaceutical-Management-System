﻿using System.ComponentModel.DataAnnotations;

namespace pharmaintel.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required]
        public string Username { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        // Note: Store hashed passwords in production!
        public string Password { get; set; }

        [Required]
        public string Role { get; set; }
    }
}
