using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace pharmaintel.Views.RawMaterials
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
