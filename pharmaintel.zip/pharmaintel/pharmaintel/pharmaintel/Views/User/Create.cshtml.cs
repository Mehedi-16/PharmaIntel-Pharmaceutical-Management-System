using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace pharmaintel.Views.User
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
