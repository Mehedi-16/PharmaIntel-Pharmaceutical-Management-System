using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace pharmaintel.Views.Inventory
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
