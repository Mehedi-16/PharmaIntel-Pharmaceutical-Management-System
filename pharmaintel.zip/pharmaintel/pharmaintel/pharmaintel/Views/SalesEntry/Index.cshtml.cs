using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace pharmaintel.Views.SalesEntry
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
