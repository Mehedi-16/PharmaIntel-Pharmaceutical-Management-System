using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace pharmaintel.Views.Customer
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
