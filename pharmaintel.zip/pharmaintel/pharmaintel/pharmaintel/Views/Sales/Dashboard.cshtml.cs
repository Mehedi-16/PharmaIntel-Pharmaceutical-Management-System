using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace pharmaintel.Views.Sales
{
    public class DashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
