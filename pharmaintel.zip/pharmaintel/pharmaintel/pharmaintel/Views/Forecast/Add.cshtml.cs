using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace pharmaintel.Views.Forecast
{
    public class AddModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
