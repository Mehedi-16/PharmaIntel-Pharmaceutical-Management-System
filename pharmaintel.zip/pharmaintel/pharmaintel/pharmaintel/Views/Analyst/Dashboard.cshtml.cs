using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace pharmaintel.Views.Analyst
{
    public class DashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
