﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using pharmaintel.Models;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;

namespace pharmaintel.Controllers
{
    public class ForecastController : Controller
    {
        private readonly string connectionString = "server=localhost;database=pharmaintel;uid=root;pwd=;";

        
        public IActionResult Index()
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "Admin" && role != "Analyst")
                return RedirectToAction("Index", "Login");

            List<SalesForecastModel> forecasts = new();

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                
                var cmd = new MySqlCommand(@"
                    SELECT P.Name, 
                           SUM(S.Quantity) AS TotalSold
                    FROM Sales S
                    JOIN Products P ON S.ProductId = P.Id
                    WHERE S.SaleDate >= CURDATE() - INTERVAL 30 DAY
                    GROUP BY P.Name
                ", conn);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int demand = reader.GetInt32("TotalSold");
                        forecasts.Add(new SalesForecastModel
                        {
                            ProductName = reader.GetString("Name"),
                            PredictedDemand = demand + 10,
                            RestockSuggestion = demand < 50 ? "Restock soon" : "Stock sufficient",
                            PromotionIdea = demand < 30 ? "Run discount or promotion" : "No promotion needed"
                        });
                    }
                }

               
                var cmd2 = new MySqlCommand("SELECT * FROM Forecasts", conn);
                using (var reader2 = cmd2.ExecuteReader())
                {
                    while (reader2.Read())
                    {
                        forecasts.Add(new SalesForecastModel
                        {
                            ProductName = reader2.GetString("ProductName"),
                            PredictedDemand = reader2.GetInt32("PredictedDemand"),
                            RestockSuggestion = reader2.GetString("RestockSuggestion"),
                            PromotionIdea = reader2.GetString("PromotionIdea")
                        });
                    }
                }
            }

            return View(forecasts);
        }

        
        [HttpGet]
        public IActionResult Add()
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "Admin" && role != "Analyst")
                return RedirectToAction("Index", "Login");

            return View();
        }


        [HttpPost]
        public IActionResult Add(SalesForecastModel model)
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "Admin" && role != "Analyst")
                return RedirectToAction("Index", "Login");

            if (!ModelState.IsValid)
                return View(model);

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                var cmd = new MySqlCommand(@"
                    INSERT INTO Forecasts (ProductName, PredictedDemand, RestockSuggestion, PromotionIdea)
                    VALUES (@ProductName, @PredictedDemand, @RestockSuggestion, @PromotionIdea)", conn);

                cmd.Parameters.AddWithValue("@ProductName", model.ProductName);
                cmd.Parameters.AddWithValue("@PredictedDemand", model.PredictedDemand);
                cmd.Parameters.AddWithValue("@RestockSuggestion", model.RestockSuggestion);
                cmd.Parameters.AddWithValue("@PromotionIdea", model.PromotionIdea);

                cmd.ExecuteNonQuery();
            }

            TempData["Success"] = "Forecast entry added!";
            return RedirectToAction("Index");
        }
    }
}
