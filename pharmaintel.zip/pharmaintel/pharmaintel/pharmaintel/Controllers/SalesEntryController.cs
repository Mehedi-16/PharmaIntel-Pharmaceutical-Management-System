﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using MySql.Data.MySqlClient;
using pharmaintel.Models;
using System;
using System.Collections.Generic;

namespace pharmaintel.Controllers
{
    public class SalesEntryController : Controller
    {
        private readonly string connectionString = "server=localhost;database=pharmaintel;uid=root;pwd=;";

        
        private List<Product> LoadProducts()
        {
            var products = new List<Product>();
            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            using var cmd = new MySqlCommand("SELECT Id, Name FROM Products", conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                products.Add(new Product
                {
                    Id = reader.GetInt32("Id"),
                    Name = reader.GetString("Name")
                });
            }
            return products;
        }

        
        [HttpGet]
        public IActionResult Index()
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "Admin" && role != "SalesManager")
                return RedirectToAction("Index", "Login");

            ViewBag.Products = LoadProducts();
            return View();
        }

       
        [HttpPost]
        public IActionResult Index(SalesEntryModel model)
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "Admin" && role != "SalesManager")
                return RedirectToAction("Index", "Login");

            if (!ModelState.IsValid)
            {
                ViewBag.Products = LoadProducts();
                return View(model);
            }

            using var conn = new MySqlConnection(connectionString);
            conn.Open();
            using var transaction = conn.BeginTransaction();

            try
            {
               
                var expiryCmd = new MySqlCommand("SELECT ExpiryDate FROM Products WHERE Id = @Id", conn, transaction);
                expiryCmd.Parameters.AddWithValue("@Id", model.ProductId);
                var expiryObj = expiryCmd.ExecuteScalar();

                if (expiryObj == null || Convert.ToDateTime(expiryObj) < DateTime.Today)
                {
                    throw new Exception("Sorry, this product has expired and cannot be sold.");
                }

                
                var insertCmd = new MySqlCommand(
                    "INSERT INTO Sales (ProductId, Quantity, Price, SaleDate) VALUES (@ProductId, @Quantity, @Price, CURDATE())",
                    conn, transaction);

                insertCmd.Parameters.AddWithValue("@ProductId", model.ProductId);
                insertCmd.Parameters.AddWithValue("@Quantity", model.Quantity);
                insertCmd.Parameters.AddWithValue("@Price", model.Price);
                insertCmd.ExecuteNonQuery();

               
                var updateCmd = new MySqlCommand(
                    "UPDATE Products SET Stock = Stock - @Quantity WHERE Id = @ProductId AND Stock >= @Quantity",
                    conn, transaction);

                updateCmd.Parameters.AddWithValue("@Quantity", model.Quantity);
                updateCmd.Parameters.AddWithValue("@ProductId", model.ProductId);

                int updatedRows = updateCmd.ExecuteNonQuery();
                if (updatedRows == 0)
                    throw new Exception("Insufficient stock to complete this sale.");

                transaction.Commit();

                TempData["Success"] = "Sale recorded and stock updated successfully.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                TempData["Error"] = ex.Message;
                ViewBag.Products = LoadProducts();
                return View(model);
            }
        }
    }
}
