﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using pharmaintel.Models;
using MySql.Data.MySqlClient;

namespace pharmaintel.Controllers
{
    public class AnalystController : Controller
    {
        private readonly string connectionString = "server=localhost;database=pharmaintel;uid=root;pwd=;";

        public IActionResult Dashboard()
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "Analyst") return RedirectToAction("Index", "Login");

            var model = new AnalystDashboardViewModel
            {
                WeeklySales = GetWeeklySales(),
                Forecasts = GetForecasts(),
                RawMaterialUsages = GetRawUsages(),
                ProfitLossSummaries = GetProfitLoss(),
                AIAlerts = GetAIAlerts(),
                ExpiringSoon = GetExpiringSoon()
            };

            return View(model);
        }

        private List<WeeklySale> GetWeeklySales()
        {
            var list = new List<WeeklySale>();
            using var conn = new MySqlConnection(connectionString);
            conn.Open();
            var cmd = new MySqlCommand(@"
                SELECT SaleDate AS Date, SUM(Quantity * Price) AS Total
                FROM Sales
                WHERE SaleDate >= CURDATE() - INTERVAL 7 DAY
                GROUP BY SaleDate", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new WeeklySale
                {
                    Date = reader.GetDateTime("Date").ToString("yyyy-MM-dd"),
                    Total = reader.GetDecimal("Total")
                });
            }
            return list;
        }

        private List<ForecastItem> GetForecasts()
        {
            var list = new List<ForecastItem>();
            using var conn = new MySqlConnection(connectionString);
            conn.Open();
            var cmd = new MySqlCommand(@"
                SELECT P.Name, SUM(S.Quantity) AS Qty
                FROM Sales S
                JOIN Products P ON S.ProductId = P.Id
                WHERE S.SaleDate >= CURDATE() - INTERVAL 30 DAY
                GROUP BY P.Name", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new ForecastItem
                {
                    Product = reader.GetString("Name"),
                    ForecastQty = reader.GetInt32("Qty") + 10
                });
            }
            return list;
        }

        private List<RawUsage> GetRawUsages()
        {
            return new List<RawUsage>
            {
                new RawUsage { Name = "Paracetamol Base", UsedQty = 120 },
                new RawUsage { Name = "Ibuprofen Salt", UsedQty = 90 }
            };
        }

        private List<ProfitLossItem> GetProfitLoss()
        {
            return new List<ProfitLossItem>
            {
                new ProfitLossItem { Name = "Napa", Revenue = 15000, Cost = 10000 },
                new ProfitLossItem { Name = "Aspirin", Revenue = 8000, Cost = 9000 }
            };
        }

        private List<string> GetAIAlerts()
        {
            return new List<string>
            {
                "Product 'Aspirin' stock too low",
                "Raw Material 'Caffeine Base' expires in 5 days"
            };
        }

        private List<string> GetExpiringSoon()
        {
            return new List<string>
            {
                "Raw Material: Ibuprofen Salt (Expiring in 3 days)",
                "Product: Napa Extra (Expiring in 10 days)"
            };
        }
    }
}
