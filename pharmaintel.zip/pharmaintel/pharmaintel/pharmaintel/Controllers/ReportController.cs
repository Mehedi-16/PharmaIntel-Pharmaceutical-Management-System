﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using pharmaintel.Models;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;

namespace pharmaintel.Controllers
{
    public class ReportController : Controller
    {
        private readonly string connStr = "server=localhost;database=pharmaintel;uid=root;pwd=;";

        public IActionResult Index(DateTime? startDate, DateTime? endDate, string category = "", int? productId = null)
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "Admin" && role != "Analyst")
                return RedirectToAction("Index", "Login");

            startDate ??= DateTime.Today.AddDays(-7);
            endDate ??= DateTime.Today;

            List<SalesReportItem> report = new();
            using (var conn = new MySqlConnection(connStr))
            {
                conn.Open();

                string query = @"
                    SELECT P.Name, SUM(S.Quantity) AS QtySold, SUM(S.Quantity * S.Price) AS Revenue
                    FROM Sales S
                    JOIN Products P ON S.ProductId = P.Id
                    WHERE S.SaleDate BETWEEN @Start AND @End";

                if (!string.IsNullOrEmpty(category))
                    query += " AND P.Category = @Category";

                if (productId.HasValue)
                    query += " AND P.Id = @ProductId";

                query += " GROUP BY P.Name";

                var cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Start", startDate.Value);
                cmd.Parameters.AddWithValue("@End", endDate.Value);
                if (!string.IsNullOrEmpty(category))
                    cmd.Parameters.AddWithValue("@Category", category);
                if (productId.HasValue)
                    cmd.Parameters.AddWithValue("@ProductId", productId.Value);

                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    var qty = reader.GetInt32("QtySold");
                    var revenue = reader.GetDecimal("Revenue");
                    var profit = revenue * 0.20m; // 20% profit margin assumption

                    report.Add(new SalesReportItem
                    {
                        ProductName = reader.GetString("Name"),
                        QuantitySold = qty,
                        TotalRevenue = revenue,
                        Profit = profit
                    });
                }
            }

            ViewBag.StartDate = startDate.Value.ToString("yyyy-MM-dd");
            ViewBag.EndDate = endDate.Value.ToString("yyyy-MM-dd");
            ViewBag.Category = category;
            ViewBag.ProductId = productId;

            return View(report);
        }
    }
}
