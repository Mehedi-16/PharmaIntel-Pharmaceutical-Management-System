﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using pharmaintel.Models;
using System;
using System.Collections.Generic;
using System.Data;

namespace pharmaintel.Controllers
{
    public class RawMaterialController : Controller
    {
        private readonly string connectionString = "server=localhost;database=pharmaintel;uid=root;pwd=;";

        private bool HasAccess()
        {
            var role = HttpContext.Session.GetString("UserRole");
            return role == "Admin" || role == "ProductionManager";
        }

        public IActionResult Index()
        {
            if (!HasAccess())
                return RedirectToAction("Index", "Login");

            List<RawMaterial> materials = new();
            using var conn = new MySqlConnection(connectionString);
            conn.Open();
            var cmd = new MySqlCommand("SELECT * FROM RawMaterials", conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                materials.Add(new RawMaterial
                {
                    Id = reader.GetInt32("Id"),
                    Name = reader.GetString("Name"),
                    Category = reader.IsDBNull("Category") ? null : reader.GetString("Category"),
                    Supplier = reader.IsDBNull("Supplier") ? null : reader.GetString("Supplier"),
                    Quantity = reader.GetInt32("Quantity"),
                    UnitPrice = reader.GetDecimal("UnitPrice"),
                    ExpiryDate = reader.IsDBNull("ExpiryDate") ? null : reader.GetDateTime("ExpiryDate")
                });
            }

            return View(materials);
        }

        [HttpGet]
        public IActionResult Create()
        {
            if (!HasAccess())
                return RedirectToAction("Index", "Login");

            return View();
        }

        [HttpPost]
        public IActionResult Create(RawMaterial model)
        {
            if (!HasAccess())
                return RedirectToAction("Index", "Login");

            if (!ModelState.IsValid)
                return View(model);

            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            var cmd = new MySqlCommand(@"
                INSERT INTO RawMaterials 
                (Name, Category, Supplier, Quantity, UnitPrice, ExpiryDate)
                VALUES (@Name, @Category, @Supplier, @Quantity, @UnitPrice, @ExpiryDate)", conn);

            cmd.Parameters.AddWithValue("@Name", model.Name);
            cmd.Parameters.AddWithValue("@Category", model.Category ?? "");
            cmd.Parameters.AddWithValue("@Supplier", model.Supplier ?? "");
            cmd.Parameters.AddWithValue("@Quantity", model.Quantity);
            cmd.Parameters.AddWithValue("@UnitPrice", model.UnitPrice);
            cmd.Parameters.AddWithValue("@ExpiryDate", (object?)model.ExpiryDate ?? DBNull.Value);

            cmd.ExecuteNonQuery();
            return RedirectToAction("Index");
        }
    }
}
