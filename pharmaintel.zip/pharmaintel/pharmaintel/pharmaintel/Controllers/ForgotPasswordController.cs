﻿using Microsoft.AspNetCore.Mvc;
using pharmaintel.Models;
using MySql.Data.MySqlClient;
using System.Net.Mail;
using System.Net;

namespace pharmaintel.Controllers
{
    public class ForgotPasswordController : Controller
    {
        private readonly string connectionString = "server=localhost;database=pharmaintel;uid=root;pwd=;";

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(ForgotPasswordModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                var cmd = new MySqlCommand("SELECT Email FROM Users WHERE Email = @Email", conn);
                cmd.Parameters.AddWithValue("@Email", model.Email);
                var result = cmd.ExecuteScalar();

                if (result == null)
                {
                    ViewBag.Message = "Email not found.";
                    return View(model);
                }

               
                ViewBag.Message = "If the email exists, a password reset link has been sent.";
            }

            return View();
        }
    }
}
