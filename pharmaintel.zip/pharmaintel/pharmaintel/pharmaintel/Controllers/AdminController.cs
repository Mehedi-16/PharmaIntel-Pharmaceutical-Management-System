﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using MySql.Data.MySqlClient;
using System.Text.Json;
using System.Collections.Generic;
using System;

namespace pharmaintel.Controllers
{
    public class AdminController : Controller
    {
        private readonly string connectionString = "server=localhost;database=pharmaintel;uid=root;pwd=;";

        public IActionResult Dashboard()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("UserRole")))
                return RedirectToAction("Index", "Login");

            int totalUsers = 0, totalProducts = 0;
            List<string> expiringSoon = new List<string>();

            
            List<string> salesLabels = new List<string>();
            List<decimal> salesData = new List<decimal>();

            List<(string Name, string Category, int Stock)> lowStockProducts = new List<(string, string, int)>();

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();

               
                var cmd1 = new MySqlCommand("SELECT COUNT(*) FROM Users", conn);
                totalUsers = Convert.ToInt32(cmd1.ExecuteScalar());

                
                var cmd2 = new MySqlCommand("SELECT COUNT(*) FROM Products", conn);
                totalProducts = Convert.ToInt32(cmd2.ExecuteScalar());

               
                var cmdExpiring = new MySqlCommand("SELECT Name FROM Products WHERE ExpiryDate <= DATE_ADD(CURDATE(), INTERVAL 15 DAY)", conn);
                var readerExp = cmdExpiring.ExecuteReader();
                while (readerExp.Read())
                {
                    expiringSoon.Add(readerExp.GetString("Name"));
                }
                readerExp.Close();

                
                List<string> rawExpiring = new List<string>();
                var cmdRaw = new MySqlCommand("SELECT Name FROM RawMaterials WHERE ExpiryDate IS NOT NULL AND ExpiryDate <= DATE_ADD(CURDATE(), INTERVAL 10 DAY)", conn);
                var readerRaw = cmdRaw.ExecuteReader();
                while (readerRaw.Read())
                {
                    rawExpiring.Add(readerRaw.GetString("Name"));
                }
                readerRaw.Close();

                ViewBag.RawExpiring = rawExpiring;

                
                var cmdLowStock = new MySqlCommand("SELECT Name, Category, Stock FROM Products WHERE Stock < 20 ORDER BY Stock ASC", conn);
                var readerLow = cmdLowStock.ExecuteReader();
                while (readerLow.Read())
                {
                    lowStockProducts.Add((
                        Name: readerLow.GetString("Name"),
                        Category: readerLow.IsDBNull(readerLow.GetOrdinal("Category")) ? "N/A" : readerLow.GetString("Category"),
                        Stock: readerLow.GetInt32("Stock")
                    ));
                }
                readerLow.Close();

                
                var cmdChart = new MySqlCommand(@"
                    SELECT DATE(SaleDate) AS SaleDay, SUM(Quantity * Price) AS TotalSale
                    FROM Sales
                    WHERE SaleDate >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                    GROUP BY SaleDay
                    ORDER BY SaleDay ASC", conn);

                var chartReader = cmdChart.ExecuteReader();
                while (chartReader.Read())
                {
                    salesLabels.Add(chartReader.GetDateTime("SaleDay").ToString("MMM dd"));
                    salesData.Add(chartReader.GetDecimal("TotalSale"));
                }
                chartReader.Close();
            }

            ViewBag.TotalUsers = totalUsers;
            ViewBag.TotalProducts = totalProducts;
            ViewBag.LowStockProducts = lowStockProducts;
            ViewBag.Expiring = expiringSoon;

            ViewBag.SalesLabels = JsonSerializer.Serialize(salesLabels);
            ViewBag.SalesData = JsonSerializer.Serialize(salesData);

            return View();
        }
    }
}
