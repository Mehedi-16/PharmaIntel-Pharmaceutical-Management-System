﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;

namespace pharmaintel.Controllers
{
    public class SalesController : Controller
    {
        private readonly string connectionString = "server=localhost;database=pharmaintel;uid=root;pwd=;";

        public IActionResult Dashboard()
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "SalesManager" && role != "Admin")
                return RedirectToAction("Index", "Login");

            decimal todaysSales = 0;
            decimal monthSales = 0;
            int lowStockCount = 0;
            List<(string name, int totalSold)> bestSellers = new();
            List<(string customerName, decimal totalSpent)> topCustomers = new();
            List<(string category, decimal salesAmount)> salesByCategory = new();

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                
                var cmdToday = new MySqlCommand("SELECT IFNULL(SUM(Quantity * Price),0) FROM Sales WHERE SaleDate = CURDATE()", conn);
                todaysSales = Convert.ToDecimal(cmdToday.ExecuteScalar());

               
                var cmdMonth = new MySqlCommand("SELECT IFNULL(SUM(Quantity * Price),0) FROM Sales WHERE MONTH(SaleDate) = MONTH(CURDATE()) AND YEAR(SaleDate) = YEAR(CURDATE())", conn);
                monthSales = Convert.ToDecimal(cmdMonth.ExecuteScalar());

               
                var cmdLowStock = new MySqlCommand("SELECT COUNT(*) FROM Products WHERE Stock < 10", conn);
                lowStockCount = Convert.ToInt32(cmdLowStock.ExecuteScalar());

               
                var cmdBestSellers = new MySqlCommand(@"
                    SELECT P.Name, SUM(S.Quantity) AS TotalSold
                    FROM Sales S
                    JOIN Products P ON S.ProductId = P.Id
                    GROUP BY P.Name
                    ORDER BY TotalSold DESC
                    LIMIT 5", conn);

                using var reader = cmdBestSellers.ExecuteReader();
                while (reader.Read())
                {
                    bestSellers.Add((reader.GetString("Name"), reader.GetInt32("TotalSold")));
                }
                reader.Close();

               
                var cmdTopCustomers = new MySqlCommand(@"
                    SELECT C.Name, SUM(S.Quantity * S.Price) AS TotalSpent
                    FROM Sales S
                    JOIN Customers C ON S.CustomerId = C.Id
                    GROUP BY C.Name
                    ORDER BY TotalSpent DESC
                    LIMIT 5", conn);

                using var readerCust = cmdTopCustomers.ExecuteReader();
                while (readerCust.Read())
                {
                    topCustomers.Add((readerCust.GetString("Name"), readerCust.GetDecimal("TotalSpent")));
                }
                readerCust.Close();

                
                var cmdSalesByCategory = new MySqlCommand(@"
                    SELECT P.Category, SUM(S.Quantity * S.Price) AS SalesAmount
                    FROM Sales S
                    JOIN Products P ON S.ProductId = P.Id
                    GROUP BY P.Category", conn);

                using var readerCat = cmdSalesByCategory.ExecuteReader();
                while (readerCat.Read())
                {
                    salesByCategory.Add((readerCat.GetString("Category"), readerCat.GetDecimal("SalesAmount")));
                }
                readerCat.Close();
            }

            ViewBag.TodaysSales = todaysSales;
            ViewBag.MonthSales = monthSales;
            ViewBag.LowStock = lowStockCount;
            ViewBag.BestSellers = bestSellers;
            ViewBag.TopCustomers = topCustomers;
            ViewBag.SalesByCategory = salesByCategory;

            return View();
        }
    }
}
