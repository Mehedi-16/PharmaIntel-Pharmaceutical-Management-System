﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using pharmaintel.Models;

namespace pharmaintel.Controllers
{
    public class LoginController : Controller
    {
        private readonly string connectionString = "server=localhost;database=pharmaintel;uid=root;pwd=;";

        
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        
        [HttpPost]
        public IActionResult Index(LoginViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            string query = "SELECT * FROM Users WHERE (Email = @input OR Username = @input) AND Password = @pass";
            using var cmd = new MySqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@input", model.EmailOrUsername);
            cmd.Parameters.AddWithValue("@pass", model.Password);

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                string role = reader["Role"].ToString();
                string username = reader["Username"].ToString();

                HttpContext.Session.SetString("UserRole", role);
                HttpContext.Session.SetString("Username", username);

                return role switch
                {
                    "Admin" => RedirectToAction("Dashboard", "Admin"),
                    "SalesManager" => RedirectToAction("Dashboard", "Sales"),
                    "Analyst" => RedirectToAction("Dashboard", "Analyst"),
                    _ => RedirectToAction("Index", "Login")
                };
            }
            else
            {
                ViewBag.Message = "Invalid credentials.";
                return View(model);
            }
        }

       
        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear(); 
            return RedirectToAction("Index", "Login");
        }
    }
}
