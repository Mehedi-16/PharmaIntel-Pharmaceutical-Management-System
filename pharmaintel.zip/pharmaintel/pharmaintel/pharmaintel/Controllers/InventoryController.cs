﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using pharmaintel.Models;
using System;
using System.Collections.Generic;

namespace pharmaintel.Controllers
{
    public class InventoryController : Controller
    {
        private readonly string connectionString = "server=localhost;database=pharmaintel;uid=root;pwd=;";

        private bool HasRole(params string[] roles)
        {
            var userRole = HttpContext.Session.GetString("UserRole");
            if (string.IsNullOrEmpty(userRole)) return false;
            foreach (var role in roles)
            {
                if (userRole.Equals(role, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }

        public IActionResult Index(string? search, string? category)
        {
            if (!HasRole("Admin", "SalesManager"))
                return RedirectToAction("Index", "Login");

            List<ProductModel> products = new();
            List<string> categories = new();

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                string query = "SELECT Id, Name, Category, Stock, ExpiryDate, Price FROM products WHERE 1=1";
                if (!string.IsNullOrEmpty(search)) query += " AND Name LIKE @search";
                if (!string.IsNullOrEmpty(category)) query += " AND Category = @category";

                var cmd = new MySqlCommand(query, conn);
                if (!string.IsNullOrEmpty(search)) cmd.Parameters.AddWithValue("@search", "%" + search + "%");
                if (!string.IsNullOrEmpty(category)) cmd.Parameters.AddWithValue("@category", category);

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    products.Add(new ProductModel
                    {
                        Id = reader.GetInt32("Id"),
                        Name = reader["Name"].ToString(),
                        Category = reader["Category"].ToString(),
                        Stock = reader["Stock"] as int?,
                        ExpiryDate = reader["ExpiryDate"] as DateTime?,
                        Price = Convert.ToDecimal(reader["Price"])
                    });
                }
                reader.Close();

                
                var catCmd = new MySqlCommand("SELECT DISTINCT Category FROM products WHERE Category IS NOT NULL", conn);
                var catReader = catCmd.ExecuteReader();
                while (catReader.Read())
                {
                    categories.Add(catReader.GetString("Category"));
                }
            }

            ViewBag.Categories = categories;
            return View(products);
        }

        public IActionResult Create()
        {
            if (!HasRole("Admin"))
                return RedirectToAction("Index", "Login");
            return View();
        }

        [HttpPost]
        public IActionResult Create(ProductModel model)
        {
            if (!HasRole("Admin"))
                return RedirectToAction("Index", "Login");

            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            var cmd = new MySqlCommand("INSERT INTO products (Name, Category, Stock, ExpiryDate, Price) VALUES (@Name, @Category, @Stock, @ExpiryDate, @Price)", conn);
            cmd.Parameters.AddWithValue("@Name", model.Name);
            cmd.Parameters.AddWithValue("@Category", model.Category);
            cmd.Parameters.AddWithValue("@Stock", model.Stock);
            cmd.Parameters.AddWithValue("@ExpiryDate", model.ExpiryDate);
            cmd.Parameters.AddWithValue("@Price", model.Price);
            cmd.ExecuteNonQuery();

            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            if (!HasRole("Admin"))
                return RedirectToAction("Index", "Login");

            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            var cmd = new MySqlCommand("SELECT * FROM products WHERE Id = @id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            var reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                var model = new ProductModel
                {
                    Id = reader.GetInt32("Id"),
                    Name = reader["Name"].ToString(),
                    Category = reader["Category"].ToString(),
                    Stock = reader["Stock"] as int?,
                    ExpiryDate = reader["ExpiryDate"] as DateTime?,
                    Price = Convert.ToDecimal(reader["Price"])
                };
                return View(model);
            }

            return NotFound();
        }

        [HttpPost]
        public IActionResult Edit(ProductModel model)
        {
            if (!HasRole("Admin"))
                return RedirectToAction("Index", "Login");

            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            var cmd = new MySqlCommand("UPDATE products SET Name=@Name, Category=@Category, Stock=@Stock, ExpiryDate=@ExpiryDate, Price=@Price WHERE Id=@Id", conn);
            cmd.Parameters.AddWithValue("@Name", model.Name);
            cmd.Parameters.AddWithValue("@Category", model.Category);
            cmd.Parameters.AddWithValue("@Stock", model.Stock);
            cmd.Parameters.AddWithValue("@ExpiryDate", model.ExpiryDate);
            cmd.Parameters.AddWithValue("@Price", model.Price);
            cmd.Parameters.AddWithValue("@Id", model.Id);
            cmd.ExecuteNonQuery();

            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            if (!HasRole("Admin"))
                return RedirectToAction("Index", "Login");

            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            var cmd = new MySqlCommand("DELETE FROM products WHERE Id = @id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();

            return RedirectToAction("Index");
        }
    }
}
