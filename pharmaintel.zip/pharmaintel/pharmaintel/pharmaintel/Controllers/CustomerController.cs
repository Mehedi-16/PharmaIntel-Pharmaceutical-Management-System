﻿using Microsoft.AspNetCore.Mvc;
using pharmaintel.Models;
using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace pharmaintel.Controllers
{
    public class CustomerController : Controller
    {
        private readonly string connectionString = "server=localhost;database=pharmaintel;uid=root;pwd=;";

        public IActionResult Index()
        {
            List<Customer> customers = new List<Customer>();

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                var cmd = new MySqlCommand("SELECT * FROM Customers", conn);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        customers.Add(new Customer
                        {
                            Id = reader.GetInt32("Id"),
                            Name = reader.GetString("Name"),
                            Email = reader.GetString("Email"),
                            Phone = reader.GetString("Phone")
                        });
                    }
                }
            }

            return View(customers);
        }
    }
}
