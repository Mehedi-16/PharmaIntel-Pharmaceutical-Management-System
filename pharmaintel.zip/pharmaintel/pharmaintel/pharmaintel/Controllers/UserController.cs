﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using MySql.Data.MySqlClient;
using pharmaintel.Models;
using System.Collections.Generic;
using System;

namespace pharmaintel.Controllers
{
    public class UserController : Controller
    {
        private readonly string connectionString = "server=localhost;database=pharmaintel;uid=root;pwd=;";

        
        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("UserRole") != "Admin")
                return RedirectToAction("Index", "Login");

            List<User> users = new();

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                var cmd = new MySqlCommand("SELECT Id, Username, Email, Role FROM Users", conn);
                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    users.Add(new User
                    {
                        Id = reader.GetInt32("Id"),
                        Username = reader.GetString("Username"),
                        Email = reader.GetString("Email"),
                        Role = reader.GetString("Role")
                    });
                }
            }

            return View(users);
        }

        
        [HttpGet]
        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("UserRole") != "Admin")
                return RedirectToAction("Index", "Login");

            return View();
        }

        
        [HttpPost]
        public IActionResult Create(User model)
        {
            if (!ModelState.IsValid)
                return View(model);

            try
            {
                using (var conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    var cmd = new MySqlCommand("INSERT INTO Users (Username, Email, Password, Role) VALUES (@Username, @Email, @Password, @Role)", conn);
                    cmd.Parameters.AddWithValue("@Username", model.Username);
                    cmd.Parameters.AddWithValue("@Email", model.Email);
                    cmd.Parameters.AddWithValue("@Password", model.Password); // For real app, hash password!
                    cmd.Parameters.AddWithValue("@Role", model.Role);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Error: " + ex.Message);
                return View(model);
            }

            return RedirectToAction("Index");
        }

       
        [HttpGet]
        public IActionResult Edit(int id)
        {
            if (HttpContext.Session.GetString("UserRole") != "Admin")
                return RedirectToAction("Index", "Login");

            User user = null;

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                var cmd = new MySqlCommand("SELECT Id, Username, Email, Role FROM Users WHERE Id = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", id);
                var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    user = new User
                    {
                        Id = reader.GetInt32("Id"),
                        Username = reader.GetString("Username"),
                        Email = reader.GetString("Email"),
                        Role = reader.GetString("Role")
                    };
                }
            }

            if (user == null)
                return NotFound();

            return View(user);
        }

        
        [HttpPost]
        public IActionResult Edit(User model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            try
            {
                using (var conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    var cmd = new MySqlCommand("UPDATE Users SET Username=@Username, Email=@Email, Role=@Role WHERE Id=@Id", conn);
                    cmd.Parameters.AddWithValue("@Username", model.Username);
                    cmd.Parameters.AddWithValue("@Email", model.Email);
                    cmd.Parameters.AddWithValue("@Role", model.Role);
                    cmd.Parameters.AddWithValue("@Id", model.Id);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected == 0)
                    {
                        ModelState.AddModelError("", "Update failed. User not found or no changes made.");
                        return View(model);
                    }
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Error: " + ex.Message);
                return View(model);
            }

            return RedirectToAction("Index");
        }

       
        [HttpGet]
        public IActionResult Delete(int id)
        {
            if (HttpContext.Session.GetString("UserRole") != "Admin")
                return RedirectToAction("Index", "Login");

            try
            {
                using (var conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    var cmd = new MySqlCommand("DELETE FROM Users WHERE Id=@Id", conn);
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.ExecuteNonQuery();
                }
            }
            catch
            {
               
            }

            return RedirectToAction("Index");
        }
    }
}
